NEXUS 固定构建流程（1.0.1）

日常网页/UI更新：
1. 更新 index.html（如需）及对应网页资源。
2. 不要覆盖 settings.gradle、build.gradle、gradle.properties、app/build.gradle、package.json、capacitor.config.json 和 .github/workflows/。
3. 将更新包按 NEXUS-update.zip 上传到仓库根目录并提交。压缩包可以包含 NEXUS-main/ 或 nexus_work/ 外层目录，也可以直接放项目文件。
4. GitHub Actions 的 Import NEXUS UI Update and Build APK 会导入网页/产品文件、保留受保护构建配置、同步 Capacitor 并构建 APK。
5. 在 Actions 运行结果的 Artifacts 下载 NEXUS-debug-apk。

也可以直接提交源码变更，Build NEXUS Android APK 会自动构建。

版本管理：app/build.gradle 中 versionName/versionCode 为 Android 安装版本。每次准备发布新版本时都必须递增 versionCode；versionName 按项目版本规则更新。当前为 1.0.1 / 2。

注意：本仓库目前构建的是 debug APK，仅用于测试。正式发布需要固定并安全保存 release signing key，再构建签名一致的 release APK/AAB。不要把签名密钥提交到仓库。
